This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `yarn`

Install dependencies

### `yarn start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### Assumptions

Parent cateogory of items is same as objectives category
Invalid parentId attributes that do not have their own entry need to be displayed
Index of the objectives will repeat with alphabet sequence, if number exceeds 25th index
