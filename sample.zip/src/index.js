import React from 'react';
import ReactDOM from 'react-dom';
import OkrContainer from './components/OkrContainer'

ReactDOM.render(<OkrContainer />, document.getElementById("root"));